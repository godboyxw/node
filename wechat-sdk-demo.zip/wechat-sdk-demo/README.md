# wechat-sdk-demo
基于nodejs的微信jssdk简单应用

description: http://www.cnblogs.com/albin-gecker/p/4628355.html

module.exports = {
	grant_type: 'client_credential',
	appid: 'wxf8337b6f556b0bb8',
	secret: 'cd8fccf9052a3bccae25f3fa398fe44c',
	noncestr:'Wm3WZYTPz0wzccnW',
	accessTokenUrl:'https://api.weixin.qq.com/cgi-bin/token',
	ticketUrl:'https://api.weixin.qq.com/cgi-bin/ticket/getticket',
	cache_duration:1000*60*60*24
}
